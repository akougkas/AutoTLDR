# Calibration note

The controller expects calibration/current.csv for Station Alpha sensor calibration. The current file is absent.
